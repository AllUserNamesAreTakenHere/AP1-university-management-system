public abstract class Users {
    String userID;
    String userType;
    public Users(String userID, String userType) {
        this.userID = userID;
        this.userType = userType;
    }
}
