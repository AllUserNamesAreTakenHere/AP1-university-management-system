public class Admin extends Users {
    public Admin(String userID, String userType) {
        super(userID,userType);
        this.userID="999999999";
        this.userType="Admin";
    }
}
