package College;

public class CollegeOfMathematicsSciences extends Colleges {
    protected CollegeOfMathematicsSciences(int collegeCode, String collegeName) {
        super(collegeCode, collegeName);
        collegeCode=20;
        collegeName="MathematicsSciences";
    }

}
