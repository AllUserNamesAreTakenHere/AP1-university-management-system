package College;

public abstract class Colleges {
    int collegeCode;
    String collegeName;

    public Colleges(int collegeCode,String collegeName) {
        this.collegeCode=collegeCode;
        this.collegeName = collegeName;
    }
}
