package College;

public class CollegeOfComputerEngineering extends Colleges {
    protected CollegeOfComputerEngineering(int collegeCode, String collegeName) {
        super(collegeCode, collegeName);
        collegeCode=23;
        collegeName="ComputerEngineering";
    }
}