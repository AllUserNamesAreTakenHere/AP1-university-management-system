public class Main {
    public static void main(String[] args) {
        CliConnector cliConnector = new CliConnector();
        cliConnector.init();
    }
}
